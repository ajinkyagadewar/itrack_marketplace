moodle-mod_flashcard
====================

A module providing a memoizong helper activity using Leitner model

2017022000 : Add models per instance selection.