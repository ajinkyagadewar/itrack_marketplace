# BuyKart Enrolment Method

This enrolment method is a clone of the core **Manual** enrolment method in Moodle, used for the [Buykart local plugin](https://github.com/Regaez/moodle-local_buykart). 