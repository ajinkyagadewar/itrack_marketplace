// $('#sidepreopen-control').click(function () {
//             $('header.navbar').addClass('drawer-open-right');
// });