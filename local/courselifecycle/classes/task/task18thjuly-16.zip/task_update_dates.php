<?php

/**
 * cron
 * @return boolean
 */

namespace local_courselifecycle\task;

defined('MOODLE_INTERNAL') || die();

class task_update_dates extends \core\task\scheduled_task {

    public function get_name() {
        // Shown in admin screens
        return get_string('pluginname', 'local_courselifecycle');
    }

    public function execute() {
        require_once(dirname(__FILE__) . '/../../../../config.php');
        global $DB;
        $generl = $DB->get_records('course_extrasettings_general', null, 'id, courseid,'
                . 'enrolstart, enrolstop, crsopen');
        foreach ($generl as $genrl1) {
            // Change Course start date in course table.
            $generalStartDate = (int) $genrl1->courseid;
            $course = $DB->get_record('course', array('id' => $generalStartDate), 'id, startdate');
            if (!empty($genrl1->crsopen)) {
                $startdate = $genrl1->crsopen;
            } else {
                $startdate = $course->startdate;
            }
            // Update startdate field only when the course stratdate!=extrasettings startdate.
            if ($course->startdate != $startdate) {
                $DB->execute("UPDATE {course} SET startdate=$startdate WHERE id=$course->id");
            }
        }

        foreach ($generl as $genrl) {
            $enrol = $DB->get_record('enrol', array('courseid' => $genrl->courseid, 'enrol' => 'self'), 'id, enrolstartdate, enrolenddate');
            $crs = $DB->get_record('course', array('id' => $genrl->courseid), 'startdate');
            // Change Enrolment Strat & End date in self enrolment plugin.
            if ((enrol_is_enabled('self')) && !empty($enrol)) {
                if (!empty($genrl->enrolstart)) {
                    $enrolstartdate = $genrl->enrolstart;
                } else {
                    if (($enrol->enrolstartdate == 0)) {
                        $enrolstartdate = $enrol->enrolstartdate + $crs->startdate;
                    } else {
                        $enrolstartdate = $enrol->enrolstartdate;
                    }
                }
                // Update only when the enrol startdate!=extrasettings enrolstart.
                if ($enrol->enrolstartdate != $enrolstartdate) {
                    $DB->execute("UPDATE {enrol} SET enrolstartdate=$enrolstartdate
                    WHERE id=$enrol->id");
                }

                if ($genrl->enrolstop != 0) {
                    $enrolenddate = $genrl->enrolstop;
                } else {
                    $enrolenddate = $enrol->enrolenddate + 4102354800; // Default 31/12/2099
                }
                // Update only when the enrol enddate!=extrasettings enrolstop.
                if ($enrol->enrolenddate != $enrolenddate) {
                    $DB->execute("UPDATE {enrol} SET enrolenddate=$enrolenddate
                    WHERE id=$enrol->id");
                }
            }
        }
    }

}
